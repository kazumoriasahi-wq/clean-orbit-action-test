export const RADIUS=18.4, MAX_AMMO=18;
export const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
export const length=(x,z)=>Math.hypot(x,z);
export function rng(seed=417){return()=>{seed|=0;seed=seed+0x6d2b79f5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
export function segmentDistance(px,pz,ax,az,bx,bz){const dx=bx-ax,dz=bz-az,t=clamp(((px-ax)*dx+(pz-az)*dz)/(dx*dx+dz*dz||1),0,1);return Math.hypot(px-ax-dx*t,pz-az-dz*t);}
export const LANDMARKS={beacons:[{x:-9,z:5},{x:9,z:3},{x:0,z:-4.4}],boss:{x:0,z:-12},start:{x:0,z:13}};
export const SCENERY=[{x:-13,z:-5.8,r:2.5,type:'pond'},{x:13,z:9,r:1.1,type:'boulder'},{x:-14,z:8,r:1,type:'boulder'},{x:4,z:10,r:1,type:'boulder'},{x:-4,z:2,r:.95,type:'boulder'},{x:4,z:-2,r:.95,type:'boulder'},{x:-12,z:-.4,r:1.25,type:'windmill'},{x:12,z:-1,r:1,type:'boulder'}];
export class Game{
 constructor(){this.reset();}
 reset(checkpoint=false){this.events=[];this.mode='ready';this.time=0;this.score=0;this.collected=0;this.damageTaken=0;this.chain=0;this.maxChain=0;this.chainTimer=0;this.shots=0;this.supplyClock=0;this.nextId=1;this.victoryTime=0;this.player={x:0,z:13,hp:6,ammo:0,faceX:0,faceZ:-1,vx:0,vz:0,inv:0,dashTime:0,dashCooldown:0,dashX:0,dashZ:-1};this.trash=[];this.enemies=[];this.props=[];this.shotsLive=[];this.hazards=[];this.waves=[];this.beacons=LANDMARKS.beacons.map((p,i)=>({...p,id:'beacon'+i,hp:8,maxHp:8,active:false,r:.85}));this.boss={x:0,z:-12,hp:100,maxHp:100,r:2.25,awake:false,timer:4,open:0,attack:0,spit:3,minionTimer:16};this.checkpoint=checkpoint;this.bossUnlocked=checkpoint;const rand=rng(417);
  const clusters=[[0,11],[-4,10],[-7,8],[-10,5],[-7,1],[1,8],[5,7],[8,5],[11,2],[7,0],[2,0],[-2,-2],[1,-5],[-7,-2],[7,-5]];
  for(const [x,z]of clusters)for(let i=0;i<9;i++){const a=rand()*Math.PI*2,r=.5+rand()*1.8;this.addTrash(x+Math.cos(a)*r,z+Math.sin(a)*r,i%3);}
  const propPositions=[[-6.7,5,'barrel'],[-6.8,2,'barrel'],[-8.7,1,'barrel'],[-10,8,'crate'],[6.5,5,'crate'],[8,0,'barrel'],[10,-.2,'barrel'],[5,1,'crate'],[-2,-3.7,'barrel'],[1,-1,'barrel'],[3,-3.7,'crate'],[-5,9,'crate']];
  for(const[x,z,type]of propPositions)this.props.push({id:this.nextId++,x,z,type,hp:type==='crate'?4:1,r:.65,alive:true});
  for(const[x,z,type]of [[-8,3,'chaser'],[-8,0,'chaser'],[7,1,'spitter'],[10,5,'chaser'],[-1,-2,'charger'],[3,-4,'chaser'],[-5,5,'chaser'],[5,6,'chaser']])this.spawnEnemy(x,z,type);
  if(checkpoint){for(const b of this.beacons){b.active=true;b.hp=0;}this.boss.awake=true;this.player.x=0;this.player.z=-5.7;this.player.ammo=12;this.enemies=[];this.props=this.props.filter(p=>p.z>5);for(let i=0;i<20;i++){const a=i*2.4;this.addTrash(Math.sin(a)*5,-10+Math.cos(a)*4,i%3);} }
 }
 start(){this.mode='playing';this.events.push({type:'start'});}
 addTrash(x,z,kind=0){if(length(x,z)>17.6)return;this.trash.push({id:this.nextId++,x,z,kind,alive:true,pull:0});}
 spawnEnemy(x,z,type='chaser'){this.enemies.push({id:this.nextId++,x,z,type,r:type==='charger'?.68:.55,hp:type==='charger'?8:6,maxHp:type==='charger'?8:6,alive:true,timer:1.3+(this.nextId%5)*.3,windup:0,tx:0,tz:0,charge:0,hit:0});}
 target(){const p=this.player,candidates=[];for(const e of this.enemies)if(e.alive)candidates.push({...e,kind:'enemy',rank:1});for(const b of this.beacons)if(!b.active)candidates.push({...b,kind:'beacon',rank:.85});if(this.boss.awake&&this.boss.hp>0)candidates.push({...this.boss,kind:'boss',rank:.65});for(const e of this.props)if(e.alive)candidates.push({...e,kind:e.type,rank:1.35});return candidates.filter(e=>length(e.x-p.x,e.z-p.z)<13).sort((a,b)=>length(a.x-p.x,a.z-p.z)*a.rank-length(b.x-p.x,b.z-p.z)*b.rank)[0]||null;}
 aim(){const t=this.target(),p=this.player;if(!t)return{x:p.faceX,z:p.faceZ};const d=length(t.x-p.x,t.z-p.z)||1;return{x:(t.x-p.x)/d,z:(t.z-p.z)/d};}
 fire(held=.01,direction=null){if(this.mode!=='playing')return false;const p=this.player;if(p.ammo<3){this.events.push({type:'empty'});return false;}const charged=held>=.42&&p.ammo>=6,spent=charged?Math.min(12,p.ammo):3,dir=direction||this.aim(),len=length(dir.x,dir.z)||1;p.ammo-=spent;this.shots++;p.faceX=dir.x/len;p.faceZ=dir.z/len;this.shotsLive.push({id:this.nextId++,x:p.x+p.faceX*.9,z:p.z+p.faceZ*.9,vx:p.faceX*19,vz:p.faceZ*19,r:charged?.37:.23,damage:charged?6+spent*.7:4,splash:charged?3.2:1.25,heavy:charged,life:1.3,bounces:charged?1:0,enemy:false});this.events.push({type:'shoot',x:p.x,z:p.z,charged,spent,dx:p.faceX,dz:p.faceZ});return true;}
 dash(mx=0,mz=0){const p=this.player;if(this.mode!=='playing'||p.dashCooldown>0)return false;const d=length(mx,mz);p.dashX=d>.1?mx/d:p.faceX;p.dashZ=d>.1?mz/d:p.faceZ;p.dashTime=.22;p.dashCooldown=2.1;p.inv=Math.max(p.inv,.38);this.events.push({type:'dash',x:p.x,z:p.z});return true;}
 addChain(x,z,kind){this.chain++;this.chainTimer=3.4;this.maxChain=Math.max(this.maxChain,this.chain);const points=100+Math.min(900,this.chain*50);this.score+=points;this.events.push({type:'destroy',x,z,kind,chain:this.chain,points});}
 damagePlayer(amount=1,x=0,z=0){const p=this.player;if(p.inv>0||this.mode!=='playing')return false;p.hp=Math.max(0,p.hp-amount);p.inv=1.15;this.damageTaken+=amount;const d=length(p.x-x,p.z-z)||1;p.x+=(p.x-x)/d*.5;p.z+=(p.z-z)/d*.5;this.events.push({type:'hurt',x:p.x,z:p.z,hp:p.hp});if(!p.hp){this.mode='failed';this.events.push({type:'end',win:false});}return true;}
 damageObject(o,amount){if(o.active||o.alive===false||o.hp<=0)return;o.hp-=amount;o.hit=.2;
  if(o.id?.toString().startsWith('beacon')){if(o.hp<=0){o.active=true;this.addChain(o.x,o.z,'beacon');this.events.push({type:'beacon',x:o.x,z:o.z,count:this.beacons.filter(b=>b.active).length});for(let i=0;i<7;i++)this.addTrash(o.x+Math.sin(i)*1.6,o.z+Math.cos(i)*1.6,i%3);if(this.beacons.every(b=>b.active))this.unlockBoss();}else this.events.push({type:'impact',x:o.x,z:o.z});}
  else if(o===this.boss){if(o.hp<=0){o.hp=0;this.score+=5000;this.mode='victory';this.victoryTime=0;this.shotsLive=[];this.hazards=[];this.waves=[];this.enemies.forEach(e=>e.alive=false);this.events.push({type:'bossDown',x:o.x,z:o.z});}else this.events.push({type:'bossHit',x:o.x,z:o.z,weak:o.open>0});}
  else if(o.hp<=0){o.alive=false;this.addChain(o.x,o.z,o.type);const count=o.type==='crate'?8:o.type==='barrel'?4:5;for(let i=0;i<count;i++)this.addTrash(o.x+Math.sin(i*2.4)*.9,o.z+Math.cos(i*2.4)*.9,i%3);if(o.type==='barrel')this.explode(o.x,o.z,3.3,12,true);if(o.type==='spitter'&&this.player.hp<6){this.player.hp++;this.events.push({type:'heal',x:o.x,z:o.z});}}
  else this.events.push({type:'impact',x:o.x,z:o.z});
 }
 explode(x,z,r,damage,chain=false){this.events.push({type:'explosion',x,z,r,chain});for(const o of [...this.props,...this.enemies,...this.beacons])if(o.alive!==false&&!o.active&&o.hp>0&&length(o.x-x,o.z-z)<r+o.r)this.damageObject(o,damage);if(this.boss.awake&&this.boss.hp>0&&length(this.boss.x-x,this.boss.z-z)<r+this.boss.r)this.damageObject(this.boss,damage*(this.boss.open>0?1.8:.6));}
 unlockBoss(){if(this.bossUnlocked)return;this.bossUnlocked=true;this.checkpoint=true;this.boss.awake=true;this.boss.timer=3.6;this.player.hp=6;this.player.ammo=Math.max(12,this.player.ammo);this.player.inv=3;this.enemies.forEach(e=>{if(e.z>-6)e.alive=false;});this.events.push({type:'bossAwake',x:0,z:-12});for(let i=0;i<24;i++){const a=i*Math.PI/12;this.addTrash(Math.sin(a)*6,-11+Math.cos(a)*5,i%3);}}
 resolvePosition(entity,r=.55){let d=length(entity.x,entity.z);if(d>RADIUS-r){entity.x*=((RADIUS-r)/d);entity.z*=((RADIUS-r)/d);}for(const o of [...SCENERY,...this.beacons,...this.props.filter(p=>p.alive)]){const rad=(o.r||.8)+r,dx=entity.x-o.x,dz=entity.z-o.z,dist=length(dx,dz);if(dist<rad&&dist>.001){entity.x=o.x+dx/dist*rad;entity.z=o.z+dz/dist*rad;}}
  const bossRadius=this.bossUnlocked?(this.boss.hp>0?this.boss.r:0):5.65;
  if(bossRadius){const dx=entity.x-this.boss.x,dz=entity.z-this.boss.z,dist=length(dx,dz),rad=bossRadius+r;if(dist<rad){entity.x=this.boss.x+(dist>.001?dx/dist:0)*rad;entity.z=this.boss.z+(dist>.001?dz/dist:1)*rad;}}
 }
 update(dt,input={x:0,z:0}){if(this.mode==='victory'){this.victoryTime+=dt;if(this.victoryTime>3){this.mode='complete';this.events.push({type:'end',win:true});}return;}if(this.mode!=='playing')return;dt=clamp(dt,0,.04);this.time+=dt;const p=this.player;p.inv=Math.max(0,p.inv-dt);p.dashCooldown=Math.max(0,p.dashCooldown-dt);p.dashTime=Math.max(0,p.dashTime-dt);this.chainTimer=Math.max(0,this.chainTimer-dt);if(this.chainTimer===0)this.chain=0;
  const len=length(input.x||0,input.z||0),speed=p.dashTime>0?17:5.8;const dx=p.dashTime>0?p.dashX:(input.x||0)/Math.max(1,len),dz=p.dashTime>0?p.dashZ:(input.z||0)/Math.max(1,len);p.vx=dx*speed;p.vz=dz*speed;p.x+=p.vx*dt;p.z+=p.vz*dt;if(len>.08){p.faceX=dx/(length(dx,dz)||1);p.faceZ=dz/(length(dx,dz)||1);}this.resolvePosition(p);
  for(const t of this.trash){if(!t.alive||p.ammo>=MAX_AMMO)continue;const dist=length(t.x-p.x,t.z-p.z);if(dist<3.5){t.pull=Math.min(1,t.pull+dt*3);const step=(3+14*t.pull)*dt;t.x+=(p.x-t.x)*Math.min(1,step/(dist||1));t.z+=(p.z-t.z)*Math.min(1,step/(dist||1));if(dist<.5){t.alive=false;p.ammo++;this.collected++;this.score+=15+Math.min(30,this.chain*3);this.events.push({type:'collect',x:t.x,z:t.z,kind:t.kind,count:this.collected});}}else t.pull=Math.max(0,t.pull-dt);}
  for(const e of this.enemies){if(!e.alive)continue;e.hit=Math.max(0,e.hit-dt);e.timer-=dt;const dx=p.x-e.x,dz=p.z-e.z,dist=length(dx,dz)||1;if(dist>8||this.time<4)continue;
   if(e.type==='spitter'){if(dist<3){e.x-=dx/dist*dt*1.8;e.z-=dz/dist*dt*1.8;}if(e.timer<0){this.enemyShot(e.x,e.z,dx/dist,dz/dist,4.8);e.timer=2.8;this.events.push({type:'enemyFire',x:e.x,z:e.z});}}
   else if(e.type==='charger'){if(e.windup>0){e.windup-=dt;if(e.windup<=0)e.charge=.65;}else if(e.charge>0){e.charge-=dt;e.x+=e.tx*dt*8;e.z+=e.tz*dt*8;}else if(e.timer<0){e.tx=dx/dist;e.tz=dz/dist;e.windup=.9;e.timer=3.4;this.events.push({type:'enemyWindup',x:e.x,z:e.z});}else if(dist>2){e.x+=dx/dist*dt*1.2;e.z+=dz/dist*dt*1.2;}}
   else{e.x+=dx/dist*dt*1.7;e.z+=dz/dist*dt*1.7;}
   this.resolvePosition(e,e.r);if(dist<e.r+.55){this.damagePlayer(1,e.x,e.z);e.x-=dx/dist*.9;e.z-=dz/dist*.9;}
  }
  this.updateBoss(dt);
  for(const h of this.hazards){h.time-=dt;if(h.time<=0&&!h.done){h.done=true;if(length(p.x-h.x,p.z-h.z)<h.r+.2)this.damagePlayer(2,h.x,h.z);this.events.push({type:'slam',x:h.x,z:h.z,r:h.r});for(let i=0;i<6;i++)this.addTrash(h.x+Math.sin(i)*2,h.z+Math.cos(i)*2,i%3);this.boss.open=2.4;}}
  this.hazards=this.hazards.filter(h=>!h.done);for(const w of this.waves){const prev=w.r;w.r+=dt*5.2;const dist=length(p.x-w.x,p.z-w.z);if(dist+.5>=prev&&dist-.5<=w.r&&p.dashTime<=0)this.damagePlayer(1,w.x,w.z);w.life-=dt;}this.waves=this.waves.filter(w=>w.life>0);
  this.updateShots(dt);if(this.mode!=='playing')return;
  this.supplyClock+=dt;if(this.supplyClock>3){this.supplyClock=0;const near=this.trash.filter(t=>t.alive&&length(t.x-p.x,t.z-p.z)<7).length;if(p.ammo<6&&near<6){const rand=rng(Math.floor(this.time*7));for(let i=0;i<9;i++){const a=rand()*Math.PI*2;this.addTrash(p.x+Math.cos(a)*2.4,p.z+Math.sin(a)*2.4,i%3);}this.events.push({type:'supply',x:p.x,z:p.z});}}
 }
 enemyShot(x,z,dx,dz,speed=5){this.shotsLive.push({id:this.nextId++,x,z,vx:dx*speed,vz:dz*speed,r:.22,life:4,enemy:true});}
 updateBoss(dt){const b=this.boss;if(!b.awake||b.hp<=0)return;b.open=Math.max(0,b.open-dt);b.timer-=dt;b.spit-=dt;b.minionTimer-=dt;b.x=Math.sin(this.time*.35)*1.1;
  if(b.timer<=0){b.attack++;b.timer=b.hp<40?3.5:5.2;this.hazards.push({id:this.nextId++,x:this.player.x,z:this.player.z,r:b.hp<40?2.7:2.25,time:1.2,maxTime:1.2,done:false});this.events.push({type:'bossWindup',x:this.player.x,z:this.player.z});if(b.attack%2===0)this.waves.push({id:this.nextId++,x:b.x,z:b.z,r:1,life:3.7});}
  if(b.spit<=0){b.spit=b.hp<40?2.2:3.3;const dx=this.player.x-b.x,dz=this.player.z-b.z,a=Math.atan2(dx,dz);for(const off of[-.2,0,.2])this.enemyShot(b.x,b.z,Math.sin(a+off),Math.cos(a+off),5);this.events.push({type:'bossSpit',x:b.x,z:b.z});}
  if(b.minionTimer<=0&&this.enemies.filter(e=>e.alive).length<4){b.minionTimer=16;this.spawnEnemy(-4,-9,'chaser');this.spawnEnemy(4,-10,'chaser');}
 }
 updateShots(dt){for(const s of this.shotsLive){if(s.life<=0)continue;s.life-=dt;const ax=s.x,az=s.z;s.x+=s.vx*dt;s.z+=s.vz*dt;
   if(s.enemy){if(segmentDistance(this.player.x,this.player.z,ax,az,s.x,s.z)<s.r+.5){s.life=0;this.damagePlayer(1,s.x,s.z);}continue;}
   let target=null;for(const o of[...this.enemies,...this.props,...this.beacons,...(this.boss.awake?[this.boss]:[])]){if(o.alive===false||o.active||o.hp<=0)continue;if(segmentDistance(o.x,o.z,ax,az,s.x,s.z)<(o.r||.7)+s.r){target=o;break;}}
   if(target){s.life=0;this.explode(s.x,s.z,s.splash,s.damage);continue;}
   for(const o of SCENERY){if(length(s.x-o.x,s.z-o.z)<o.r+s.r){if(s.bounces>0){const dx=s.x-o.x,dz=s.z-o.z,len=length(dx,dz)||1,nx=dx/len,nz=dz/len,dot=s.vx*nx+s.vz*nz;s.vx-=2*dot*nx;s.vz-=2*dot*nz;s.x=o.x+nx*(o.r+s.r+.1);s.z=o.z+nz*(o.r+s.r+.1);s.bounces--;this.events.push({type:'ricochet',x:s.x,z:s.z});}else{s.life=0;this.events.push({type:'impact',x:s.x,z:s.z});}break;}}
  }this.shotsLive=this.shotsLive.filter(s=>s.life>0&&length(s.x,s.z)<23);}
 drain(){return this.events.splice(0);}
}
